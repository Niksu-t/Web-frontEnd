import '../css/style.css';
import '../css/snackbar.css';

document.querySelector('#app').innerHTML = 'Moi tässä oman APIn harjoituksia';
